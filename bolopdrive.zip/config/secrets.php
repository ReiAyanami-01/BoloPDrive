<?php
declare(strict_types=1);

// ⚠️ Pega aquí TU NUEVA API KEY (la que generes ahora) y un remitente verificado en Brevo
const BREVO_API_KEY      = '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';
const MAIL_SENDER_NAME   = 'BOLO P-Drive';
const MAIL_SENDER_EMAIL  = 'n3lmijo@gmail.com'; // verificado en Brevo

// Para firmar/hashear el OTP
const OTP_PEPPER         = '69';

// Configuración OTP
const OTP_TTL_SECONDS    = 600; // 10 minutos
const OTP_MAX_ATTEMPTS   = 5;
const GOOGLE_MAPS_API_KEY = 'AIzaSyDhRy87DuQH0rBX17t5uD9DuaSYZmlB7UY';
